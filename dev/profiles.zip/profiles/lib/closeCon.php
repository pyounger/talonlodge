<?php
mysql_close($conn);
ob_end_flush();
?>