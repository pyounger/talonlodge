<?php
if(isset($_SESSION["UType"])){
    if($_SESSION["UType"]==3){
                    $menuList = Array(
                    1 => Array(
                            'title' => 'My Profile',
                            'link' => 'manage_profile.php',
                            'icon' => 'th-large',
                            'children' => Array()
                    ),
                    2 => Array(
                            'title' => 'Log Out',
                            'link' => 'logout.php',
                            'icon' => 'user',
                            'children' => Array()
                    )
            );
    }
    elseif($_SESSION["UType"]==2){
                    $menuList = Array(
                    0 => Array(
                            'title' => 'Dashboard',
                            'link' => 'index.php',
                            'icon' => 'dashboard',
                            'children' => Array()
                    ),
                    1 => Array(
                            'title' => 'Group Management',
                            'link' => 'javascript:void(0);',
                            'icon' => 'indent',
                            'children' => Array(
                                    0 => Array(
                                            'title' => 'Group',
                                            'link' => 'manage_group.php',
                                            'icon' => 'th-large',
                                            'children' => Array()
                                    ),
                                    1 => Array(
                                            'title' => 'Guest Profiles',
                                            'link' => 'manage_profile.php',
                                            'icon' => 'th-large',
                                            'children' => Array()
                                    )
                            )
                    ),
                    2 => Array(
                            'title' => 'Profile Report',
                            'link' => 'javascript:void(0);',
                            'icon' => 'indent',
                            'children' => Array(
                                1 => Array(
                                    'title' => 'Profile Report',
                                    'link' =>  'manage_pr_stats.php',
                                    'icon' =>  'file-text',
                                    'children' => Array()
                                )
                           )
                    )
            );
    }
    else{
            $menuList = Array(
                    0 => Array(
                            'title' => 'Dashboard',
                            'link' => 'index.php',
                            'icon' => 'dashboard',
                            'children' => Array()
                    ),
                    1 => Array(
                            'title' => 'Group Management',
                            'link' => 'javascript:void(0);',
                            'icon' => 'indent',
                            'children' => Array(
//                                    0 => Array(
//                                            'title' => 'Customer',
//                                            'link' => 'manage_customers.php',
//                                            'icon' => 'th-large',
//                                            'children' => Array()
//                                    ),
                                    1 => Array(
                                            'title' => 'Confirmed Groups',
                                            'link' => 'manage_group.php',
                                            'icon' => 'th-large',
                                            'children' => Array()
                                    ),
                                    2 => Array(
                                            'title' => 'Unconfirmed Groups',
                                            'link' => 'manage_uc_group.php',
                                            'icon' => 'th-large',
                                            'children' => Array()
                                    ),
                                    3 => Array(
                                            'title' => 'Guest Profiles',
                                            'link' => 'manage_profile.php',
                                            'icon' => 'user',
                                            'children' => Array()
                                    )
                           )
                    ),
                    3 => Array(
                            'title' => 'Profile Report',
                            'link' => 'javascript:void(0);',
                            'icon' => 'indent',
                            'children' => Array(
                                    1 => Array(
                                            'title' => 'Profile Report',
                                            'link' => 'manage_pr_stats.php',
                                            'icon' => 'file-text',
                                            'children' => Array()
                                    )
                           )
                    ),
                    4 => Array(
                            'title' => 'Flight Information',
                            'link' => 'javascript:void(0);',
                            'icon' => 'indent',
                            'children' => Array(
                                    1 => Array(
										'title' => 'Flight Name',
										'link' => 'manage_flight_name.php',
										'icon' => 'file-text',
										'children' => Array()
                                    ),
                                    2 => Array(
										'title' => 'Flight Time',
										'link' => 'manage_flight_time.php',
										'icon' => 'clock-o',
										'children' => Array()
                                    ),
                                    3 => Array(
										'title' => 'Flight Number',
										'link' => 'manage_flight_number.php',
										'icon' => 'sort-numeric-asc',
										'children' => Array()
                                    ),
                                    4 => Array(
										'title' => 'Hotels',
										'link' => 'manage_hotels.php',
										'icon' => 'cutlery',
										'children' => Array()
                                    )
                           )
                    ),
                    2 => Array(
                            'title' => 'Management',
                            'link' => 'javascript:void(0);',
                            'icon' => 'indent',
                            'children' => Array(
                                    3 => Array(
                                            'title' => 'Rooms',
                                            'link' => 'manage_rooms.php',
                                            'icon' => 'windows',
                                            'children' => Array()
                                    ),
                                    4 => Array(
                                            'title' => 'Room Reservation',
                                            'link' => 'manage_rooms_reservation.php',
                                            'icon' => 'windows',
                                            'children' => Array()
                                    ),
                                    5 => Array(
                                            'title' => 'Activities',
                                            'link' => 'manage_activities.php',
                                            'icon' => 'eye',
                                            'children' => Array()
                                    ),
                                    6 => Array(
                                            'title' => 'Activities Schedules',
                                            'link' => 'manage_activities_schedule.php',
                                            'icon' => 'eye',
                                            'children' => Array()
                                    ),
                                    7 => Array(
                                            'title' => 'Manage Packages',
                                            'link' => 'manage_packages.php',
                                            'icon' => 'list',
                                            'children' => Array(),
                                    ),
                                    8 => Array(
                                            'title' => 'Manage Bar Items',
                                            'link' => 'manage_barItems.php',
                                            'icon' => 'glass',
                                            'children' => Array()
                                    ),
//                                    9 => Array(
//                                            'title' => 'Contact',
//                                            'link' => 'contacts_manage.php',
//                                            'icon' => 'user',
//                                            'children' => Array()
//                                    ),
                                    10 => Array(
                                            'title' => 'Question',
                                            'link' => 'manage_questions.php',
                                            'icon' => 'question',
                                            'children' => Array()
                                    ),
//                                    11 => Array(
//                                            'title' => 'Fish Record',
//                                            'link' => 'manage_fish.php',
//                                            'icon' => 'gears',
//                                            'children' => Array()
//                                    ),
                                    11 => Array(
                                            'title' => 'Contacts',
                                            'link' => 'manage_users.php',
                                            'icon' => 'user',
                                            'children' => Array()
                                    ),
                                    20 => Array(
                                            'title' => 'Log Out',
                                            'link' => 'logout.php',
                                            'icon' => 'power-off',
                                            'children' => Array()
                                    )
                            )
                    )
            );
    }
}
function buildMenu($menuList) {
    $pieces = explode('/', $_SERVER['REQUEST_URI']);
    $page = end($pieces);
    foreach ($menuList as $val => $node) {
        $active = (strpos($page, $node['link']) !== false) ? "active" : " ";
        if (!empty($node['children'])) {
            echo " <li class='submenu " . $active . "'><a class='dropdown' href='" . $node['link'] . "' data-original-title='" . $node['title'] . "'><i class='fa fa-" . $node['icon'] . "'></i><span class='hidden-minibar'> " . $node['title'] . "  <span class='badge bg-primary pull-right'></span></span></a>";
        } else {
            echo "<li class='" . $active . "' ><a href='" . $node['link'] . "' data-original-title='" . $node['title'] . "'><i class='fa fa-" . $node['icon'] . "'></i><span class='hidden-minibar'> " . $node['title'] . "</span></a>";
        }
        if (!empty($node['children'])) {
            echo "<ul>";
            buildMenu($node['children']);
            echo "</ul>";
        }
        echo "</li>";
    }
}
function totalCounts($field, $from, $where) {
    if($where!=''){
        $Query = "SELECT $field FROM $from WHERE $where ";
    } else {
        $Query = "SELECT $field FROM $from ";
    }    
    $pro = mysql_query($Query);
    return $total_rec = mysql_num_rows($pro);
}
function FillSelected($Table, $IDField, $TextField, $ID) {
    $strQuery = "SELECT $IDField, $TextField FROM $Table ORDER BY $IDField";
    $nResult = mysql_query($strQuery);
    if (mysql_num_rows($nResult) >= 1) {
        while ($row = mysql_fetch_row($nResult)) {
            if ($row[0] == $ID) {
                print("<option value=\"$row[0]\" selected>$row[1]</option>");
            } else {
                print("<option value=\"$row[0]\">$row[1]</option>");
            }
        }
    }
}
function FillSelected2($Table, $IDField, $TextField1, $TextField2, $ID) {
    $strQuery = "SELECT $IDField, $TextField1, $TextField2 FROM $Table ORDER BY $IDField";
    $nResult = mysql_query($strQuery);
    if (mysql_num_rows($nResult) >= 1) {
        while ($row = mysql_fetch_row($nResult)) {
            if ($row[0] == $ID) {
                print("<option value=\"$row[0]\" selected>$row[1]"." "."$row[2]</option>");
            } else {
                print("<option value=\"$row[0]\">$row[1]"." "."$row[2]</option>");
            }
        }
    }
}
function FillSelected3($Table, $IDField, $TextField1, $TextField2, $TextField3, $ID) {
    $strQuery = "SELECT $IDField, $TextField1, $TextField2, $TextField3 FROM $Table ORDER BY $IDField";
    $nResult = mysql_query($strQuery);
    if (mysql_num_rows($nResult) >= 1) {
        while ($row = mysql_fetch_row($nResult)) {
            if ($row[0] == $ID) {
                echo "<option value=".$row[0]." selected>".$row[1]." - ".calendarDateConver2($row[2])." - ".$row[3]."</option>";
            } else {
                echo "<option value=".$row[0].">".$row[1]." - ".calendarDateConver2($row[2])." - ".$row[3]."</option>";
            }
        }
    }
}
function getMaximum($Table, $Field) {
    $maxID = 0;
    $strQry = "SELECT MAX(" . $Field . ")+1 as CID FROM " . $Table . " ";
    $nResult = mysql_query($strQry);
    if (mysql_num_rows($nResult) >= 1) {
        while ($row = mysql_fetch_object($nResult)) {
            if (@$row->CID)
                $maxID = $row->CID;
            else
                $maxID = 1;
        }
    }
    return $maxID;
}
function chkExist($Field, $Table, $WHERE){
    $retRes = 0;
    $strQry = "SELECT $Field FROM $Table $WHERE";
    $nResult = mysql_query($strQry) or die("Unable 2 Work");
    if (mysql_num_rows($nResult) >= 1) {
        $row = mysql_fetch_row($nResult);
        $retRes = $row[0];
        //$retRes=1;
    }
    return $retRes;
}
function returnName($Field, $Table, $IDField, $ID) {
    $retRes = "";
    $strQry = "SELECT $Field FROM $Table WHERE $IDField=$ID LIMIT 1";
    //$nResult = mysql_query($strQry) or die(mysql_error()."Unable 2 Work");
    $nResult = mysql_query($strQry);
    if (mysql_num_rows($nResult) >= 1) {
        $row = mysql_fetch_row($nResult);
        $retRes = $row[0];
    }
    return $retRes;
}
function calendarDateConver($date){
    if($date!=''){
        $arrDate = explode('/',$date);
        return $arrDate[2].'-'.$arrDate[0].'-'.$arrDate[1].' 00:00:00';
    } else {
        return '00-00-00'.' 00:00:00';
    }    
}
function calendarDateConver4($date){
    if($date!=''){
        $arrDate = explode('/',$date);
        return $arrDate[2].'-'.$arrDate[0].'-'.$arrDate[1];
    } else {
        return '0000-00-00';
    }    
}
function calendarDateConver3($date){
    if($date!=''){
	$arrDate1 = explode(' ',$date);
	$arrDate2 = explode('/',$arrDate1[0]);
	return $arrDate2[2].'-'.$arrDate2[0].'-'.$arrDate2[1].' '.@$arrDate1[1];
    } else {
	return '';
    }    
}
function calendarDateConver2($date){
    if($date!=''){
	$arrDate = explode(' ',$date);
	$arrDate = explode('-',$arrDate[0]);
	return $arrDate[1].'/'.$arrDate[2].'/'.$arrDate[0];
    } else {
        return '00/00/0000';
    }
}
function dbStr($str) {
    $string = str_replace("'", "''", $str); // Converts ' to ' in database, but ' to '' in the static page
    return $string;
}
?>