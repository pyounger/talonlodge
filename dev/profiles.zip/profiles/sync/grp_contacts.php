<?php
ob_start();
session_start();
include("../../lib/openCon.php");
include("../../lib/functions.php");
if (isset($_REQUEST['getGrpContacts'])) {
    $rs = mysql_query("SELECT Pms_Booking_ID FROM group_contacts ORDER BY Pms_Booking_ID DESC LIMIT 0, 1");
    if (mysql_num_rows($rs) > 0) {
        $row = mysql_fetch_object($rs);
        $lastID = $row->Pms_Booking_ID;
    } else {
        $lastID = 0;
    }
    $url = utf8_encode(file_get_contents('http://private.talonlodge.com/guests/talon_service.asp?function=getGrpContacts&lastID='.$lastID));
    $varData = simplexml_load_string($url);
    foreach ($varData as $dInfo):
        $isExist = chkExist("Pms_Booking_ID", "group_contacts", "WHERE Pms_Booking_ID=" . $dInfo->Pms_Booking_ID . " AND ContactID=" . $dInfo->ContactID);
        if ($isExist == 0) {
            $grp_id = returnName("grp_id", "groups", "Pms_Booking_ID", $dInfo->Pms_Booking_ID);
            if($grp_id!=''&&$grp_id!=0){
                mysql_query("INSERT INTO group_contacts (gcont_id, grp_id, Pms_Booking_ID, ContactID, GroupArrivalDate, createdDate) VALUES (coalesce((SELECT MAX(gc.gcont_id) as ID FROM group_contacts AS gc), 0)+1, '" . $grp_id . "', '" . $dInfo->Pms_Booking_ID . "', '" . $dInfo->ContactID . "', '" . calendarDateConver4($dInfo->GroupArrivalDate) . "', '" . calendarDateConver4($dInfo->GroupArrivalDate) . "')") or die(mysql_error());
            }
        }
    endforeach;
    header("Location: ../manage_group.php?op=8");
}
ob_end_flush();
?>