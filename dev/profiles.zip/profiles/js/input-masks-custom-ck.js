jQuery(function(e) {
    e("#date").mask("99/99/9999");
    e("#phone").mask("(999) 999-9999");
    e("#taxid").mask("99-9999999");
    e("#phext").mask("(999) 999-9999? x99999");
    e("#ssn").mask("999-99-9999");
    e("#percent").mask("99%");
    e("#pkey").mask("a*-999-a999");
    e("#eyescript").mask("~9.99 ~9.99 999");
    e("#currency").mask("$99,99,99,99");
});