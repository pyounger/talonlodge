$('document').ready(function(){
	//data table
	$('#example').dataTable({
		"sPaginationType": "bootstrap"
	});
});