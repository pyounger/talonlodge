// jQuery $('document').ready(); function 
$("document").ready(function() {
    $("#editor").wysiwyg();
    $("#colorpicker").colorpicker();
});