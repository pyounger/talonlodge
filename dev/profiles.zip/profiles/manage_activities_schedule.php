<?php include('includes/php_includes_top.php'); ?>
<?php
if (isset($_REQUEST['action'])) {
    if (isset($_REQUEST['btnAdd'])) {
        $actsid = getMaximum("act_schedule", "asch_id");
        mysql_query("INSERT INTO act_schedule(asch_id,grp_id,cont_id,act_id,asch_start_datetime,asch_end_datetime,createdDate) VALUES(" . $actsid . ",'" . $_REQUEST['grp_id'] . "', '" . $_REQUEST['ContactID'] . "','" . $_REQUEST['act_id'] . "','" . calendarDateConver($_REQUEST['asch_start_datetime']) . "','" . calendarDateConver($_REQUEST['asch_end_datetime']) . "',NOW())") or die(mysql_error());
        header("Location: " . $_SERVER['PHP_SELF'] . "?op=1");
    } elseif (isset($_REQUEST['btnUpdate'])) {
        //$staName = returnName("status_name", "status", "status_id", $_REQUEST['status_id']);

        $udtQuery = "UPDATE act_schedule SET grp_id='" . $_REQUEST['grp_id'] . "',cont_id='" . $_REQUEST['ContactID'] . "',
		act_id='" . $_REQUEST['act_id'] . "', asch_start_datetime='" . calendarDateConver($_REQUEST['asch_start_datetime']) . "' , asch_end_datetime='" . calendarDateConver($_REQUEST['asch_end_datetime']) . "'
		,lastUpdated=NOW() WHERE asch_id=" . $_REQUEST['asch_id'];
        mysql_query($udtQuery) or die(mysql_error());
        header("Location: " . $_SERVER['PHP_SELF'] . "?op=2");
    } elseif ($_REQUEST['action'] == 2) {
        $rsM = mysql_query("SELECT * FROM act_schedule WHERE asch_id=" . $_REQUEST['asch_id']);
        if (mysql_num_rows($rsM) > 0) {
            $rsMem = mysql_fetch_object($rsM);
            $asch_id = $rsMem->asch_id;
            $grp_id = $rsMem->grp_id;
            $ContactID = $rsMem->cont_id;
            $act_id = $rsMem->act_id;
            $asch_start_datetime = $rsMem->asch_start_datetime;
            $asch_end_datetime = $rsMem->asch_end_datetime;
            $lastUpdated = $rsMem->lastUpdated;
            $formHead = "Update Info";
        }
    } else {
        $asch_id = "";
        $grp_id = "";
        $ContactID = "";
        $act_id = "";
        $asch_start_datetime = "";
        $asch_end_datetime = "";
        $lastUpdated = "";
        $formHead = "Add New";
    }
}
if (isset($_REQUEST['show'])) {
    $rsM = mysql_query("SELECT m.*, s.ContactFirstName, s.ContactLastName, g.GroupName, ac.act_name FROM act_schedule AS m LEFT OUTER JOIN contacts AS s ON s.cont_id=m.cont_id LEFT OUTER JOIN groups AS g ON m.grp_id=g.grp_id LEFT OUTER JOIN activities AS ac ON m.act_id=ac.act_id WHERE m.asch_id=".$_REQUEST['asch_id']);
    if (mysql_num_rows($rsM) > 0) {
        $rsMem = mysql_fetch_object($rsM);
        $act_name = $rsMem->act_name;
        $asch_start_datetime = $rsMem->asch_start_datetime;
        $asch_end_datetime = $rsMem->asch_end_datetime;
        $createdDate = $rsMem->createdDate;
        $lastUpdated = $rsMem->lastUpdated;
        $ContactFirstName = $rsMem->ContactFirstName;
        $ContactLastName = $rsMem->ContactLastName;
        $GroupName = $rsMem->GroupName;
        $formHead = "Details";
    }
}
if (isset($_REQUEST['btnDelete'])) {
    @mysql_query("DELETE FROM act_schedule  WHERE asch_id=" . $_REQUEST['chkstatus']) or die(mysql_query());
    header("Location: " . $_SERVER['PHP_SELF'] . "?op=3");

    
//    if (isset($_REQUEST['chkstatus'])) {
//        for ($i = 0; $i < count($_REQUEST['chkstatus']); $i++) {
//            mysql_query("DELETE FROM act_schedule  WHERE asch_id=" . $_REQUEST['chkstatus'][$i]) or die(mysql_query());
//        }
//        $class = "alert alert-success";
//        $strMSG = "Record(s) deleted successfully";
//    } else {
//        $class = "alert alert-danger";
//        $strMSG = "Please check atleast one checkbox";
//    }
}
?>



<?php include('includes/html_header.php'); ?>
<div class="row">
    <div class="col-mod-12">
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
        </ul>
        <div class="form-group hiddn-minibar pull-right">
            <!--<input type="text" class="form-control form-cascade-control nav-input-search" size="20" placeholder="Search through site" />
            <span class="input-icon fui-search"></span>-->
        </div>
        <h3 class="page-header"> Manage Activities Schedules <i class="fa fa-info-circle animated bounceInDown show-info"></i></h3>
        <blockquote class="page-information hidden">
            <p> <b>Manage Activities Schedules: </b> You can manage your activity schedules here </p>
        </blockquote>
    </div>
</div>


<?php if (isset($_REQUEST['action'])) { ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-cascade">
                <div class="panel-heading">
                    <h3 class="panel-title text-primary">
                        <?php print($formHead); ?>

                    </h3>
                </div>
                <div class="panel-body panel-border">
                    <form name="frm" id="frm" method="post" class="form-horizontal" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" role="form">
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Group</label>
                            <div class="col-lg-10 col-md-9">
                                <select data-placeholder="Choose a Group..." name="grp_id" id="grp_id" class="chosen-select required" style="width:240px;" tabindex="2">
                                    <option value=""></option>
                                    <?php FillSelected("groups", "grp_id", "GroupName", $grp_id); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Contact First Name</label>
                            <div class="col-lg-10 col-md-9">
                                <select data-placeholder="Choose a Contact..." name="ContactID" id="ContactID" class="chosen-select required" style="width:240px;" tabindex="2">
                                    <option value=""></option>
                                    <?php FillSelected("contacts", "ContactID", "ContactFirstName", $ContactID); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Activities  Name</label>
                            <div class="col-lg-10 col-md-9">
                                <select data-placeholder="Choose an Activity..." name="act_id" id="act_id" class="chosen-select required" style="width:240px;" tabindex="2">
                                    <option value=""></option>
    <?php FillSelected("activities", "act_id", "act_name", $act_id); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Start Date</label>
                            <div class="col-lg-10 col-md-9">
                                <input type="text" class="form-control form-cascade-control input_wid70 required datetimepicker" placeholder="Start Date..." 
                                       id="asch_start_datetime" name="asch_start_datetime" value="<?php print($asch_start_datetime); ?>" style="width:180px;">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">End Date</label>
                            <div class="col-lg-10 col-md-9">
                                <input type="text" class="form-control form-cascade-control input_wid70 required datetimepicker" placeholder="End Date..." 
                                       id="asch_end_datetime" name="asch_end_datetime" value="<?php print($asch_end_datetime); ?>" style="width:180px;">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputEmail1" class="col-lg-2 col-md-3 control-label">&nbsp;</label>
                            <div class="col-lg-10 col-md-9">
    <?php if ($_REQUEST['action'] == 1) { ?>
                                    <button type="submit" name="btnAdd" class="btn btn-primary btn-animate-demo">Submit</button>
    <?php } else { ?>
                                    <button type="submit" name="btnUpdate" class="btn btn-primary btn-animate-demo">Submit</button>
    <?php } ?>
                                <button type="button" name="btnCancel" class="btn btn-default btn-animate-demo" onclick="javascript: window.location = '<?php print($_SERVER['PHP_SELF']); ?>';">Cancel</button>
                            </div>
                        </div>

                    </form> 
                </div>
                <!-- /panel body --> 
            </div>
        </div>
    </div>
<?php } elseif (isset($_REQUEST['show'])) { ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-cascade">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Details
                    </h3>
                </div>
                <div class="panel-body">
                    <form name="frm" id="frm" method="post" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" class="form-horizontal" role="form">
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Activity Name</label>
                            <div class="col-lg-10 col-md-9"><?php echo $act_name;?></div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Activity Start Date</label>
                            <div class="col-lg-10 col-md-9"><?php echo $asch_start_datetime;?></div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Activity End Date</label>
                            <div class="col-lg-10 col-md-9"><?php echo $asch_end_datetime;?></div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Contact Name</label>
                            <div class="col-lg-10 col-md-9"><?php echo $ContactFirstName.' '.$ContactLastName;?></div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Group Name</label>
                            <div class="col-lg-10 col-md-9"><?php echo $GroupName;?></div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Created</label>
                            <div class="col-lg-10 col-md-9"><?php echo $createdDate;?></div>
                        </div>
                        <div class="form-group">
                            <label for="site_login" class="col-lg-2 col-md-3 control-label">Last Updated</label>
                            <div class="col-lg-10 col-md-9"><?php echo $lastUpdated;?></div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail1" class="col-lg-2 col-md-3 control-label">&nbsp;</label>
                            <div class="col-lg-10 col-md-9">
                                <button type="button" name="btnBack" class="btn btn-default btn-animate-demo" onclick="javascript: window.location = '<?php print($_SERVER['PHP_SELF']); ?>';">Back</button>
                            </div>
                        </div>					
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <div class="row">
        <div class="col-md-12">
            <div class="<?php print($class); ?>"><?php print($strMSG); ?></div>
            <div class="panel">
                <div class="panel-heading text-primary">
                    <h3 class="panel-title"><i class="fa fa-sitemap"></i> Activity Schedule
                        <span class="pull-right" style="width:auto;">
                        <!--<div class="btn-group code"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Classes used"><i class="fa fa-code"></i></a>
                                <ul class="dropdown-menu pull-right list-group" role="menu">
                                        <li class="list-group-item"><code>.table-condensed</code></li>
                                        <li class="list-group-item"><code>.table-hover</code></li>
                                </ul>
                        </div>
                        <a  href="#" class="panel-minimize"><i class="fa fa-chevron-up"></i></a> <a  href="#"  class="panel-close"><i class="fa fa-times"></i></a> -->
                            <div style="float:right;"><a href="<?php print($_SERVER['PHP_SELF'] . "?action=1"); ?>" title="Add New"><i class="fa fa-plus"></i> Add New</a></div>
                        </span> 
                    </h3>
                </div>
                <div class="panel-body">
                    <form name="frm" id="frm" method="post" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" class="form-horizontal" role="form">
                        <table class="table users-table table-condensed table-hover table-striped" >
                            <thead>
                                <tr>
                                    <th class="visible-xs visible-sm visible-md visible-lg">Contact Name</th>
                                    <th class="visible-xs visible-sm visible-md visible-lg">Start Date</th>
                                    <th class="visible-sm visible-md visible-lg">End Date</th>
                                    <th style="text-align:center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
    <?php
    if ($_SESSION['cont_id'] > 0) {
        $Query = "SELECT ash.*, c.ContactFirstName, c.ContactLastName FROM act_schedule AS ash LEFT OUTER JOIN contacts AS c ON c.ContactID=ash.cont_id  WHERE asc.cont_id=" . $_SESSION['cont_id'] . "";
    } else {
        $Query = "SELECT ash.*, c.ContactFirstName, c.ContactLastName FROM act_schedule AS ash LEFT OUTER JOIN contacts AS c ON c.ContactID=ash.cont_id";
    }
    
    //echo $Query;
    
    $counter = 0;
    $limit = 25;
    $start = $p->findStart($limit);
    $count = mysql_num_rows(mysql_query($Query));
    $pages = $p->findPages($count, $limit);
    $rs = mysql_query($Query . " LIMIT " . $start . ", " . $limit);
    if (mysql_num_rows($rs) > 0) {
        while ($row = mysql_fetch_object($rs)) {
            $counter++;
            ?>
                                        <tr> 
                                            <td class="visible-xs visible-sm visible-md visible-lg"><?php print($row->ContactFirstName.' '.$row->ContactLastName); ?> </td>
                                            <td class="visible-xs visible-sm visible-md visible-lg"><?php print($row->asch_start_datetime); ?> </td>
                                            <td  class="visible-sm visible-md visible-lg"><?php print($row->asch_end_datetime); ?> </td>
                                            <td style="width:140px">
                                                <div class="tooltips"><a href="manage_activities_schedule.php?asch_id=<?php print($row->asch_id); ?>&btnDelete=1&chkstatus=<?php print($row->asch_id);?>" data-original-title="Delete Record" data-placement="top" class="btn bg-primary text-white" style="float:left; margin-left: 2px;"><i class="fa fa-minus-circle"></i></a></div>
                                                <div class="tooltips"><a href="<?php print($_SERVER['PHP_SELF'] . "?show=1&asch_id=" . $row->asch_id); ?>" data-original-title="See Details" data-placement="top" class="btn bg-primary text-white" style="float:left; margin-left: 2px;"><i class="fa fa-eye"></i></a></div>
                                                <div class="tooltips"><a href="<?php print($_SERVER['PHP_SELF'] . "?action=2&asch_id=" . $row->asch_id); ?>" data-original-title="Update Record" data-placement="top" class="btn bg-primary text-white" style="float:left; margin-left: 2px;"><i class="fa fa-edit"></i></a></div>
                                            </td>
                                        </tr>
            <?php
        }
    } else {
        print('<tr><td colspan="100%" align="center">No record found!</td></tr>');
    }
    ?>
                            </tbody>
                        </table>
                                <?php if ($counter > 0) { ?>
                            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td><?php print("Page <b>" . $_GET['page'] . "</b> of " . $pages); ?></td>
                                    <td align="right">
                                    <?php
                                    $next_prev = $p->nextPrev($_GET['page'], $pages, '');
                                    print($next_prev);
                                    ?>
                                    </td>
                                </tr>
                            </table>
                                    <?php } ?>
                                    <?php if ($counter > 0) { ?>
        <!--<input type="submit" name="btnActive" value="Active" class="btn btn-primary btn-animate-demo">
        <input type="submit" name="btnInactive" value="In Active" class="btn btn-danger btn-animate-demo">-->
                                    <?php } ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

                    <?php } ?>    


</div>
<?php include("includes/rightsidebar.php"); ?>
</div> </div> </div>
<?php include("includes/footer.php"); ?>

