<?php

//define('SITE_URL', 'http://localhost/core/fuss/ );
//define('TBL_GENERS', 'contacts');

?>