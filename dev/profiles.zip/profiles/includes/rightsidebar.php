<div class="right-sidebar right-sidebar-hidden">
    <div class="right-sidebar-holder"> 
        <ul class="list-group theme-options">
            <li class="list-group-item" href="#">
                <div class="form-group backgroundImage hidden" >
                    <label class="control-label">Paste Image Url and then hit enter</label>
                    <input type="text" class="form-control" id="backgroundImageUrl" />
                </div>
            </li>
        </ul>
    </div>
</div>